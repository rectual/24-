//#ifndef __Round_H_
//#define __Round_H_
//
//#include "headfile.h"
//
//
//int check_round(int L,int R,int num_R,int entered_Cross);
//int check_Round_status2(int row);
//int check_Round_status3();
//int check_Round_status4(int num1);
//int check_Round_status5(int L);
//int check_Round_status6();
//void seek_round_dot1(uint8 img[120][188]);
//void Repair_Round_status1(int row);
//void Repair_Round_status2();
//void Repair_Round_status4();
//void Repair_Round_status5(int row,int num_R_row);
//
//void Round_control();
//
//#define   enter_round 95
//#define   round_correct_bend_error 0
//#define   out_round 32
//#define   road_width 120
//
//
//#endif
