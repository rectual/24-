/*
 * PLC.h
 *
 *  Created on:
 *  Author: heavywood
 */

#ifndef PLC_H_
#define PLC_H_

#include "headfile.h"
void Daimxa_Pc_Display188x120(void);


#endif /* PLC_H_ */
