#ifndef __CrossRound_H_
#define __CrossRound_H_

#include "headfile.h"


int link_Line(int V,int row,int type);  //y=bx+a
void Repair_Line();
int check_cross_road_out(int num1,int b);//�ж�ʮ��
void seek_vary_pot(int b);
void Cross_Round_control();
void Cross_Round_control();

#endif
