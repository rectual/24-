#ifndef __Show_H_
#define __Show_H_

#include "headfile.h"

void Left_line_draw();
void Right_line_draw();
void Center_line_draw();
void draw_fill_circle(uint8 x0,uint8 y0,uint8 r,const uint16 color);//д��ʵ��Բ��(x0,y0),�뾶r

#endif
