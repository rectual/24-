/********************************** (C) COPYRIGHT *******************************
* File Name          : ch32v30x_it.h
* Author             : L
* Version            : V1.0.0
* Date               : 
* Description        : This file contains the headers of the interrupt handlers.
*******************************************************************************/
#ifndef __CH32V30x_IT_H
#define __CH32V30x_IT_H
#include "headfile.h"



#endif /* __CH32V30x_IT_H */


